docker run --rm -p 6080:80 -p 2222:22 --shm-size=512m -e HOME=/home/ubuntu -e SHELL=/bin/bash --entrypoint '/startup.sh' turtlebot3_kinetic
